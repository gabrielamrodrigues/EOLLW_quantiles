rm(list=ls(all=TRUE))
library(tidyverse)
library(lubridate)
library(survival)
library(readxl)
library(ggplot2)
library(survminer)
library(gridExtra)
library(knitr)
library(sm)
require(gamlss.cens)
require(survival)
library(dplyr)
library(ggplot2)


#Gamlss models

source('EOLLW_050.R')
source('EOLLW_025.R')
source('EOLLW_075.R')
source('EOLLW_010.R')
source('EOLLW_090.R')
source('EOLLW_001.R')
source('EOLLW_099.R')

#Dataset

dados <- read_excel("data_gastric.xlsx")

dados$lauren <- as.numeric(dados$lauren)
dados$pm <- as.numeric(dados$pm)
class(dados$lauren)
class(dados$pm)

#Descriptive analysis

km1 <- survfit(Surv(times, cens) ~lauren, data = dados)
km2 <- survfit(Surv(times, cens) ~pm, data = dados)
plot(km1)
plot(km2)

print(km1, rmean = "individual")
print(km2, rmean = "individual")
summary(km1)
summary(km2)

quantile(km1)
quantile(km2)


##Regression models

##Quantile 050

#Marginal analysis (Model M_0)

#EOLLW MODEL
fit050.EOLLW <- gamlss(Surv(times, cens)~1,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001)

#OLLW MODEL
fit050.OLLW <- gamlss(Surv(times, cens)~1,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001,tau.fix = T,tau.start = 1)

#Exp-W MODEL
fit050.EW <- gamlss(Surv(times, cens)~1,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001,nu.fix = T,nu.start = 1)

#WEIBULL MODEL
fit050.W <- gamlss(Surv(times, cens)~1,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001,nu.fix = T,nu.start = 1,tau.fix = T,tau.start = 1)


AIC(fit050.EOLLW,fit050.OLLW,fit050.EW,fit050.W)

##'For quantile 0.10 use: family(EOLLW_010)
##'For quantile 0.25 use: family(EOLLW_025)
##'For quantile 0.75 use: family(EOLLW_075)
##'For quantile 0.90 use: family(EOLLW_090)

##Model M_1

#EOLLW MODEL
fit050.EOLLW.m1 <- gamlss(Surv(times, cens)~lauren+pm,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001)

#OLLW MODEL
fit050.OLLW.m1 <- gamlss(Surv(times, cens)~lauren+pm,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001,tau.fix = T,tau.start = 1)

#Exp-W MODEL
fit050.EW.m1 <- gamlss(Surv(times, cens)~lauren+pm,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001,nu.fix = T,nu.start = 1)

#WEIBULL MODEL
fit050.W.m1 <- gamlss(Surv(times, cens)~lauren+pm,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001,nu.fix = T,nu.start = 1,tau.fix = T,tau.start = 1)

AIC(fit050.EOLLW.m1,fit050.OLLW.m1,fit050.EW.m1,fit050.W.m1)

##'For quantile 0.10 use: family(EOLLW_010)
##'For quantile 0.25 use: family(EOLLW_025)
##'For quantile 0.75 use: family(EOLLW_075)
##'For quantile 0.90 use: family(EOLLW_090)


##Model M_2

#EOLLW MODEL
fit050.EOLLW.m2 <- gamlss(Surv(times, cens)~lauren+pm,sigma.formula=~lauren+pm,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001)

#OLLW MODEL
fit050.OLLW.m2 <- gamlss(Surv(times, cens)~lauren+pm,sigma.formula=~lauren+pm,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001,tau.fix = T,tau.start = 1)

#Exp-W MODEL
fit050.EW.m2 <- gamlss(Surv(times, cens)~lauren+pm,sigma.formula=~lauren+pm,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001,nu.fix = T,nu.start = 1)

#WEIBULL MODEL
fit050.W.m2 <- gamlss(Surv(times, cens)~lauren+pm,sigma.formula=~lauren+pm,family=cens(EOLLW_050),data=dados, n.cyc=20000,c.crit=0.0001,nu.fix = T,nu.start = 1,tau.fix = T,tau.start = 1)

AIC(fit050.EOLLW.m2,fit050.OLLW.m2,fit050.EW.m2,fit050.W.m2)

##'For quantile 0.10 use: family(EOLLW_010)
##'For quantile 0.25 use: family(EOLLW_025)
##'For quantile 0.75 use: family(EOLLW_075)
##'For quantile 0.90 use: family(EOLLW_090)

##LR statistics Model M_2

LR.test(fit010.OLLW.m2,fit010.EOLLW.m2)
LR.test(fit025.OLLW.m2,fit025.EOLLW.m2)
LR.test(fit050.OLLW.m2,fit050.EOLLW.m2)
LR.test(fit075.OLLW.m2,fit075.EOLLW.m2)
LR.test(fit090.OLLW.m2,fit090.EOLLW.m2)

##MLEs and SEs from the ELLOW QR model
summary(fit010.EOLLW.m2,type='qr')
summary(fit025.EOLLW.m2,type='qr')
summary(fit050.EOLLW.m2,type='qr')
summary(fit075.EOLLW.m2,type='qr')
summary(fit090.EOLLW.m2,type='qr')

##Confidence interval

significance <- 0.05
z <- qnorm(1-(significance/2))

models <- list(fit001.EOLLW.m2,fit010.EOLLW.m2,fit025.EOLLW.m2,fit050.EOLLW.m2,fit075.EOLLW.m2,fit090.EOLLW.m2,fit099.EOLLW.m2)
ics <- list()

for (i in 1:length(models)) {
  
  model <- models[[i]]
  model.summary <- summary(model,type='qr')
  estimates <- model.summary[,1]
  ses <- model.summary[,2]
  
  ics[[i]] <- data.frame(estimates, ses,ic.lower=estimates-z*ses, ic.upper=estimates+z*ses)
}

ics

##Residuals - Models M_2

qqnorm(fit010.W.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit010.EW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit010.OLLW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit010.EOLLW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)

qqnorm(fit025.W.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit025.EW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit025.OLLW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit025.EOLLW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)

qqnorm(fit050.W.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit050.EW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit050.OLLW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit050.EOLLW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)

qqnorm(fit075.W.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit075.EW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit075.OLLW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit075.EOLLW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)

qqnorm(fit090.W.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit090.EW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit090.OLLW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)
qqnorm(fit090.EOLLW.m2$residuals, pch=20)
abline(0,1, col='gray',lwd=3)

index <- seq(1:length(fit010.EOLLW.m2$residuals))
plot(index, fit050.EOLLW.m2$residuals, pch=20, ylim = c(-4.4,4.4), ylab = 'Quantile residual')
abline(h=-3,lwd=3,lty=2,col="gray")
abline(h=3,lwd=3,lty=2,col="gray")


index <- seq(1:length(fit025.EOLLW.m2$residuals))
plot(index, fit050.EOLLW.m2$residuals, pch=20, ylim = c(-4.4,4.4), ylab = 'Quantile residual')
abline(h=-3,lwd=3,lty=2,col="gray")
abline(h=3,lwd=3,lty=2,col="gray")


index <- seq(1:length(fit050.EOLLW.m2$residuals))
plot(index, fit050.EOLLW.m2$residuals, pch=20, ylim = c(-4.4,4.4), ylab = 'Quantile residual')
abline(h=-3,lwd=3,lty=2,col="gray")
abline(h=3,lwd=3,lty=2,col="gray")

index <- seq(1:length(fit075.EOLLW.m2$residuals))
plot(index, fit050.EOLLW.m2$residuals, pch=20, ylim = c(-4.4,4.4), ylab = 'Quantile residual')
abline(h=-3,lwd=3,lty=2,col="gray")
abline(h=3,lwd=3,lty=2,col="gray")

index <- seq(1:length(fit090.EOLLW.m2$residuals))
plot(index, fit050.EOLLW.m2$residuals, pch=20, ylim = c(-4.4,4.4), ylab = 'Quantile residual')
abline(h=-3,lwd=3,lty=2,col="gray")
abline(h=3,lwd=3,lty=2,col="gray")

